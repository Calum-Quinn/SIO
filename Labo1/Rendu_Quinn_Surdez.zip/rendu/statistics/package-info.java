/**
 * This package provides basic tools for collecting data and computing statistics.
 */
package statistics;