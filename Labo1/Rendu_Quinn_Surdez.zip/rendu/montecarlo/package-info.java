/**
 * This package provides classes and interfaces to perform simple Monte Carlo simulations.
 */
package montecarlo;