*************************************
Simulation results - Experiment 1
*************************************
- Number of rounds generated: 94400000
- Estimated prob. of doubling amount:    0.432859
- Confidence interval (95%):  0.43286 +/- 0.000100
- Time taken (ms): 25753

*************************************
Simulation results - Experiment 2
*************************************
- Number of rounds generated: 377300000
- Estimated prob. of doubling amount:    0.432817
- Confidence interval (95%):  0.43282 +/- 0.000050
- Time taken (ms): 106531

*************************************
Simulation results - Experiment 3
*************************************
- Number of rounds generated: 1508900000
- Estimated prob. of doubling amount:    0.432827
- Confidence interval (95%):  0.43283 +/- 0.000025
- Time taken (ms): 425045
